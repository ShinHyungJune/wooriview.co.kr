$(document).ready(function(){
    $('#gnb').load('components/gnb.html');
});





